
<h2 align="center"> Screen Recorder GUI </h2>

SYNOPSIS

A customizable gui for screen recording with ffmpeg.exe 

USAGE

1. Run script.
2. in GUI click 'Get ffmpeg.exe'
3. input desired variables and click start
4. Timestamped output file will be in the same folder as the script.
