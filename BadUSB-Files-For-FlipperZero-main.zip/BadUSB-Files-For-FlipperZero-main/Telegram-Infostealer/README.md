
<h2 align="center"> Telegram System InfoStealer </h2>

SYNOPSIS

This script gathers system information and posts to Telegram Bot Chat with the results.

SETUP INSTRUCTIONS

1. visit https://t.me/botfather and make a bot.
2. add bot api to script.
3. search for bot in top left box in telegram and start a chat then type /start.
4. Replace YOUR_BOT_TOKEN_FOR_TELEGRAM with your bot token
5. Run Script on target System
