<h2 align="center"> Keylogger To WebHook - Chrome Extension </h2>

SYNOPSIS

Creates the neccessary files for a chrome extension that logs all keystrokes on any website.
Then sends the collected keys to a discord webhook.

USAGE
1. Replace YOUR_WEBHOOK_HERE with your webhook. (in the .txt file.)
2. add the txt to your badUSB device and run the script.
3. test by going to a website in chrome browser (eg. google.com) and type some keys
4. Wait 20 seconds and check webhook for results. 

CREDITS - Kudos and credit to jakov for the js!
