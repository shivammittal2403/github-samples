
<h2 align="center"> Saved Wifi Networks to Discord </h2>

SYNOPSIS

This script gathers WiFi information and posts to a discord webhook address with the results.

USAGE

1. Input your credentials below
2. Run Script on target System
3. Check Discord for results

