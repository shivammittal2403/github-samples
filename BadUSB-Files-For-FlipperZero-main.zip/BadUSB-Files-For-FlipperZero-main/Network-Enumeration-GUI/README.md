
<h2 align="center"> Network Enumeration GUI </h2>

SYNOPSIS

This script creates a GUI window for enumerating devices on the local network.
