
<h2 align="center"> Simple Shortcut Bomb </h2>


SYNOPSIS

This script will create 200 shortcuts on the desktop very quickly.

USAGE

1. Change '100' to the number of shortcuts you want created
2. Run the script.