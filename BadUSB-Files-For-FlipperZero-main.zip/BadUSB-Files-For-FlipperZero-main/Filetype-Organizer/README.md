
<h2 align="center"> Search Folders For Filetypes </h2>

SYNOPSIS

Searches User folder for any files with specific filetype and copies them.

USAGE

1. Run Script.
2. follow instructions in the console.