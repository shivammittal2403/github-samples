
<h2 align="center"> Screenshot to Discord </h2>

SYNOPSIS

Takes a screenshot of the desktop and posts to a discord webhook.

SETUP

1. replace DISCORD_WEBHOOK_HERE with your Discord Webhook.
