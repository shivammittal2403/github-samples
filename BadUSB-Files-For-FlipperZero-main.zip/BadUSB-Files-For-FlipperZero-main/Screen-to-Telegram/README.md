
<h2 align="center"> Screenshot to Telegram </h2>

SYNOPSIS

Takes a screenshot of the desktop and posts to a Telegram bot chat.

SETUP

1. replace TELEGRAM_TOKEN_HERE with your Telegram token.
