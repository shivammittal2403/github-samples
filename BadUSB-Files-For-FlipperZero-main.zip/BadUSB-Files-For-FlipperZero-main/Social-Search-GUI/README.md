
<h2 align="center"> Social Search GUI </h2>

SYNOPSIS

This script presents a GUI for searching popular websites with a single username..

USAGE

1. Run script with powershell
2. Input your desired username
3. Press "Start Search"
