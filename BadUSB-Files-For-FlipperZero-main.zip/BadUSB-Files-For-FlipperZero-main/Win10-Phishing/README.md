
<h2 align="center"> Fake Windows Logon Screen to Discord Webhook </h2>


SYNOPSIS

This script kills all egde and chrome processes, starts screensaver and opens edge in fullscreen that asks for login info and posts results to a discord webhook.

USAGE

1. Replace YOUR_WEBBHOOK_HERE with your webhook.
2. Run script on target system.
