
<h2 align="center"> Exfiltrate Files to Discord </h2>

SYNOPSIS

This script searches the user folders for specific filetypes to upload to Discord zipped.

SETUP

Create a webhook in a discord server channel settings.
Replace WEBHOOK_HERE with your webhook.

