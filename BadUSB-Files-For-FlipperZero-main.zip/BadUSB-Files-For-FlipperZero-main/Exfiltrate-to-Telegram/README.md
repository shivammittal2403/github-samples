
<h2 align="center"> Exfiltrate Files to Telegram </h2>

SYNOPSIS

This script connects target computer with a telegram chat to upload certain files to telegram .

SETUP INSTRUCTIONS

1. visit https://t.me/botfather and make a bot.
2. add bot api to script.
3. search for bot in top left box in telegram and start a chat then type /start.
4. Replace TELEGRAM_TOKEN with your token
5. Run Script on target System