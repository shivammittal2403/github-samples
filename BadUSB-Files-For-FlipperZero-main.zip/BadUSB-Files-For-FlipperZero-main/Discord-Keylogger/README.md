
<h2 align="center"> Keylogger To Discord Webhook </h2>


SYNOPSIS

This script gathers Keypress information and posts to a discord webhook address with the results only
when the keyboard is inactive for more than 10 seconds and only if keys were pressed before that.

USAGE

1. Input your credentials below
2. Run Script on target System
3. Check Discord for results
