
<h2 align="center"> Filesystem Monitor to discord </h2>

SYNOPSIS

This script gathers information about any changes to any files in the "%USERPROFILE% folder".

USAGE
2. Run Script on target System
3. Check temp folder for results
