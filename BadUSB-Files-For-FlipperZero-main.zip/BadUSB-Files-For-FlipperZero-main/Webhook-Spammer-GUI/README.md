
<h2 align="center"> Discord Spammer With GUI </h2>

SYNOPSIS

Creates a GUI with functionality to spam a webhook with text or an image.

USAGE

1. Run script with powershell
2. Input ip Range and select additional parameters
3. Press "Start Scan"
