
<h2 align="center"> Beigeworm's Powershell LAN Toolset </h2>

MAIN SCRIPT HERE - https://github.com/beigeworm/Posh-LAN

SYNOPSIS

Start up a HTTP server and run a selection of Local Area Network Tools using Powershell.

USAGE

1. Run this script on target computer and note the URL provided
2. on another device on the same network, enter the provided URL in a browser window

NOTE

This script will need Admin privaleges to run properly.
