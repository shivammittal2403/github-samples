
<h2 align="center"> Set US Keyboard Layout </h2>

SYNOPSIS

This script changes the keyboard layout and system language to US.

USAGE

1. Run the script on a target system