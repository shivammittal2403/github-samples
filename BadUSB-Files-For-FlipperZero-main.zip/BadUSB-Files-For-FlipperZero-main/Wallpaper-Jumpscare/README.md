
<h2 align="center"> Simple Wallpaper Changer </h2>

SYNOPSIS

This script will download an image from the web and set it as the wallpaper.

USAGE

1. Change DIRECT IMAGE LINK HERE to your URL.
2. Run the script.
