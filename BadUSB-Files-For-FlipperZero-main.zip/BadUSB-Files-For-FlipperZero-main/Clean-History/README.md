
<h2 align="center"> History Cleaner </h2>

SYNOPSIS
Empty the temp folder and recycle bin, clear run box and powershell history.

USAGE
1. Run the script

CREDIT
this code was pulled from I-Am-Jakoby's recon script. 

#>
