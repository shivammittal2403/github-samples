
<h2 align="center"> GIF Player in Powershell </h2>

SYNOPSIS

This Script downloads a GIF from Giphy and plays it in a GUI window.

USAGE

1. Run this script in powershell
