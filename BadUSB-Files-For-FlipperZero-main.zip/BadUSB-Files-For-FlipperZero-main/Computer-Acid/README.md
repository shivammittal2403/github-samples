
<h2 align="center"> Computer Acid Prank </h2>

SYNOPSIS

this script generates GDI effects (VISUAL EFFECTS) on the desktop
(lasts for 90 seconds before returning to normal)

USAGE

1. Run script with powershell