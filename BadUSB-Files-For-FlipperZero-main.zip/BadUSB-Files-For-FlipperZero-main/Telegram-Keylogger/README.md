
<h2 align="center"> Keylogger To Telegram Chat </h2>

SYNOPSIS

This script connects target computer with a telegram chat to capture keystrokes.

SETUP INSTRUCTIONS

1. visit https://t.me/botfather and make a bot.
2. add bot api to script.
3. search for bot in top left box in telegram and start a chat then type /start.
5. Run Script on target System
