
<h2 align="center"> Discord System InfoStealer </h2>

SYNOPSIS

This script gathers system information and posts to Discord Webhook with the results.

SETUP INSTRUCTIONS

4. Replace DISCORD_WEBHOOK with your webhook
5. Run Script on target System
