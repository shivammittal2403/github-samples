
<h2 align="center"> Exfiltrate Files to USB </h2>

SYNOPSIS

Waits for a new USB Storage device to be connected and then copies many user files to that USB drive.

USAGE

1. Run the script.
2. Choose if you want to hide the console window (silent mode)
3. Connect a USB Drive to the computer
4. Copying files will automatically begin to the newly connected drive
5. 'Completed' message will appear when finished (hidden mode only)

