
<h2 align="center"> Download and Execute exe files </h2>

SYNOPSIS

Uses the Run Prompt to download a file and run it.

USAGE

replace FILE_URL_HERE with the url of your file to run.
Run script on target Windows system.
