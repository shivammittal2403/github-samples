
<h2 align="center"> Browser History and Bookmarks to Discord </h2>

SYNOPSIS

Gathers History and Bookmarks data from database files and sends it to discord

USAGE

1. Replace YOUR_WEBHOOK_HERE with your Discord webhook.
2. Run the script and check Discord for results.