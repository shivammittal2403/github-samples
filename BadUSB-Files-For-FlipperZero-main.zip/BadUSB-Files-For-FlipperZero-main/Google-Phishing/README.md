
<h2 align="center"> Google Sign in to Discord </h2>

SYNOPSIS

Uses Powershell and HTML to create a fake google login page which catches login credentials and sends them to a webhook.

USAGE

1. Replace YOUR_WEBBHOOK_HERE with your webhook
2. Run script on target system.
