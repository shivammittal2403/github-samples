
<h2 align="center"> Mouse Monitor to Discord </h2>

SYNOPSIS

This script gathers information about any mouse movement and idletime and sends info to Discord".

USAGE

2. Run Script on target System
3. Check Discord for results
